# Exercise 6 - Student Survey using JPA
 
## Overview
### Home
<p align='center'>
<img src='https://raw.githubusercontent.com/rizqialfani01/JPA-student-survey/master/home.png' width='475'>
</p>

### Form
<p align='center'>
<img src='https://raw.githubusercontent.com/rizqialfani01/JPA-student-survey/master/form.png' width='475'>
</p>

### Saved Data
<p align='center'>
<img src='https://raw.githubusercontent.com/rizqialfani01/JPA-student-survey/master/data.png' width='475'>
</p>